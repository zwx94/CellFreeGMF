from distutils.core import setup
setup(name='CellFreeGMF', version='1.1.1', author='Wenxiang Zhang')